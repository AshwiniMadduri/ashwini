"""
Expense Tracker (Tkinter) with visuals, CSV upload, categorization, budget alerts, and Excel export.

This version shows friendly error popups if required packages are missing and
uses the TkAgg backend for matplotlib embedding.
"""

import sys
# Ensure tkinter is available for error popups
try:
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox
except Exception as e:
    print("tkinter is required but not available on this system:", e)
    sys.exit(1)

# Check optional dependencies and show helpful message if missing
missing = []
try:
    import pandas as pd
except ModuleNotFoundError:
    missing.append("pandas")
try:
    import matplotlib
    # Use TkAgg for embedding in Tkinter
    matplotlib.use("TkAgg")
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
except ModuleNotFoundError:
    missing.append("matplotlib")
try:
    import tempfile
    import os
except Exception:
    # tempfile/os are in stdlib; if they fail something is very wrong
    pass

if missing:
    msg = (
        "Missing Python packages: " + ", ".join(missing) + "\n\n"
        "Install them in your project's environment and re-run the app.\n\n"
        "Windows PowerShell (recommended):\n"
        "  python -m pip install --upgrade pip\n"
        "  python -m pip install pandas matplotlib openpyxl XlsxWriter\n\n"
        "Then run:\n"
        "  python app.py\n\n"
        "If you use VS Code, be sure the selected interpreter is the one where you installed the packages.\n"
        "Do NOT run files directly from inside a .zip archive — save this project folder and open that folder in VS Code."
    )
    # show GUI popup and also print to terminal
    try:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Missing dependencies", msg)
        root.destroy()
    except Exception:
        print(msg)
    sys.exit(1)

# --------------------------
# Utilities: data handling
# --------------------------
SAMPLE_PATH = os.path.join("data", "sample_expenses.csv")

def load_csv(path):
    try:
        df = pd.read_csv(path)
        return df
    except Exception as e:
        messagebox.showerror("Load error", f"Could not read CSV: {e}")
        return pd.DataFrame()

def load_sample_data():
    if not os.path.exists(SAMPLE_PATH):
        messagebox.showerror("Missing file", f"Sample file not found at {SAMPLE_PATH}")
        return pd.DataFrame()
    return load_csv(SAMPLE_PATH)

def clean_data(df):
    if df is None or df.empty:
        return pd.DataFrame()
    df = df.rename(columns=lambda c: c.strip())
    if 'Date' not in df.columns or 'Amount' not in df.columns:
        messagebox.showerror("CSV format", "CSV must contain 'Date' and 'Amount' columns.")
        return pd.DataFrame()
    df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
    df['Amount'] = pd.to_numeric(df['Amount'], errors='coerce')
    df = df.dropna(subset=['Date','Amount']).copy()
    df['Amount'] = df['Amount'].astype(float)
    if 'Description' not in df.columns:
        df['Description'] = ''
    else:
        df['Description'] = df['Description'].fillna('')
    if 'Category' not in df.columns:
        df['Category'] = ''
    else:
        df['Category'] = df['Category'].fillna('')
    return df

# Simple categorizer (same rules as earlier)
def infer_category(row, rules):
    if row.get('Category'):
        return row['Category']
    desc = f"{row.get('Description','')} {row.get('Notes','')}".lower()
    for cat, keywords in rules.items():
        for kw in keywords:
            if kw in desc:
                return cat
    return 'Other'

def apply_categorization(df):
    rules = {
        'Food': ['restaurant','cafe','coffee','dinner','lunch','breakfast','uber eats','uber_eats','grocer','grocery','supermarket','pizza'],
        'Transport': ['uber','lyft','taxi','bus','train','gas','fuel','metro'],
        'Rent': ['rent','landlord','apartment'],
        'Utilities': ['electric','water','internet','phone','utility'],
        'Entertainment': ['netflix','spotify','movie','concert','game','theatre'],
        'Shopping': ['amazon','store','mall','clothes','shirt','shoes'],
        'Healthcare': ['pharmacy','doctor','hospital','clinic','dentist'],
        'Subscriptions': ['subscription','saas','membership'],
        'Salary': ['salary','payroll','paycheck','income','deposit'],
        'Other': []
    }
    df['Category'] = df.apply(lambda r: infer_category(r, rules), axis=1)
    return df

def monthly_summary(df):
    df2 = df.copy()
    df2['YearMonth'] = df2['Date'].dt.to_period('M').astype(str)
    monthly = df2.groupby('YearMonth')['Amount'].sum().reset_index()
    return monthly

def category_summary(df):
    cat = df.groupby('Category')['Amount'].sum().reset_index().sort_values('Amount', ascending=False)
    return cat

def daily_cumulative(df):
    daily = df.groupby('Date')['Amount'].sum().sort_index().cumsum().reset_index()
    return daily

def parse_budget_text(text):
    budgets = {}
    if not text:
        return budgets
    for part in text.split(','):
        if ':' in part:
            k,v = part.split(':',1)
            try:
                budgets[k.strip()] = float(v.strip())
            except:
                continue
    return budgets

def export_to_excel(df, cat_summary, monthly_summary_df, pie_fig, bar_fig, outpath):
    # Save Excel with xlsxwriter and insert pie/bar images
    tmpdir = tempfile.mkdtemp()
    pie_path = os.path.join(tmpdir, "pie.png")
    bar_path = os.path.join(tmpdir, "bar.png")
    pie_fig.savefig(pie_path, bbox_inches='tight')
    bar_fig.savefig(bar_path, bbox_inches='tight')

    writer = pd.ExcelWriter(outpath, engine='xlsxwriter')
    df.to_excel(writer, index=False, sheet_name='Raw Data')
    cat_summary.to_excel(writer, index=False, sheet_name='By Category')
    monthly_summary_df.to_excel(writer, index=False, sheet_name='By Month')

    workbook  = writer.book
    worksheet = workbook.add_worksheet('Charts')
    # insert images
    worksheet.insert_image('B2', pie_path)
    worksheet.insert_image('B22', bar_path)

    writer.close()
    try:
        os.remove(pie_path)
        os.remove(bar_path)
    except:
        pass

# (The rest of the UI code is unchanged — same as previous Tkinter app implementation)
# For brevity, please reuse the previously provided Tkinter UI code below this point.
# If you want the complete file with UI again I can paste the full content here.