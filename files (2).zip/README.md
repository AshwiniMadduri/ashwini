```markdown
# Expense Tracker (Tkinter)

This is a desktop Expense Tracker using Tkinter, pandas and matplotlib.

Features:
- Load CSV or the provided sample CSV (data/sample_expenses.csv)
- Auto-clean and rule-based categorization
- Filter by date range and category
- Embedded charts (category pie, monthly totals bar)
- Budget alerts (overall monthly and per-category)
- Export filtered data + summaries and charts to Excel (.xlsx)

Requirements
- Python 3.8 - 3.11 recommended
- Install required packages (see requirements.txt)

Quick start:
1. Create and activate a virtual environment (recommended):
   - Windows (PowerShell):
     ```
     python -m venv .venv
     .\.venv\Scripts\Activate.ps1
     ```
   - macOS / Linux:
     ```
     python3 -m venv .venv
     source .venv/bin/activate
     ```

2. Install packages:
   ```
   pip install -r requirements.txt
   ```

3. Run the app:
   ```
   python app.py
   ```

Notes:
- The CSV must contain at least `Date` and `Amount` columns. Optional columns: `Description`, `Category`, `Notes`.
- Date entry fields expect `YYYY-MM-DD`.
- To export: apply filters then click "Export to Excel" and pick a filename.
```